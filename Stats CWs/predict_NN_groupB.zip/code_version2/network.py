# neural network
import torch
import torch.nn as nn
import numpy as np
from torch.utils.data import DataLoader, Dataset
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
from torch.optim.lr_scheduler import StepLR


class Net(nn.Module):
    
    __doc__ = r""" neural network model"""
    
    def __init__(self, in_chns, out_chns=1):
        """
        in_chns:  Input feature dimension
        out_chns: Output feature dimension
        """
        super(Net, self).__init__()
        
        self.relu = nn.SiLU()  # activation function
        self.dropout = nn.Dropout(0.2)  # random dropout to prevent overfitting
        
        #* 第一套方法
        self.linear1 = nn.Linear(in_chns, 32)    # Fully connected layer 1
        self.linear2 = nn.Linear(32, 16)         # Fully connected layer 2
        self.linear3 = nn.Linear(16, out_chns)   # Fully connected layer 3
        
        self.norm1 = nn.LayerNorm(32)  # Normalization layer 1
        self.norm2 = nn.LayerNorm(16)  # Normalization layer 2

    
    def forward(self, x):
        """
        x: Input data
        """
        x = x.unsqueeze(1)
        
        x = self.linear1(x)
        x = self.relu(x)
        x = self.dropout(x)
        
        x = self.linear2(x)
        x = self.relu(x)
        x = self.dropout(x)
        
        x = self.linear3(x)
        
        x = x.squeeze(1)
        return x
    

class MyDataset(Dataset):
    
    __doc__ = r""" Dataset processing"""
    
    def __init__(self, x, y):
        """
        x: Input data
        y: Output data
        """
        self.x = x
        self.y = y
        
    def __len__(self):
        return len(self.x)
    
    def __getitem__(self, idx):
        return self.x[idx], self.y[idx]
    
        
        
def train_net(data_x, data_y, epochs=100, in_chns=3, batch_size=64):

    # Divide training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(data_x, data_y, test_size=0.1, random_state=100)
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    net = Net(in_chns=in_chns, out_chns=1).to(device)  # initial model
    
    criterion = nn.SmoothL1Loss()  # loss function
    optimizer = torch.optim.Adamax(net.parameters(), lr=1e-3)  # initial optimizer
    
    train_set = MyDataset(X_train, y_train)  # Construct training set
    train_loader = DataLoader(dataset=train_set, batch_size=batch_size, shuffle=True)
    
    valid_set = MyDataset(X_test, y_test)  # Construct validation set
    valid_loader = DataLoader(dataset=valid_set, batch_size=10, shuffle=False)
    
    scheduler = StepLR(optimizer, step_size=30, gamma=0.65)  # The learning rate decays by 0.65 times every 30 epochs
    
    train_mse  = []  # Save training loss
    valid_mse  = []  # Save validation loss
    
    for epoch in range(epochs):
        
        #Training model
        train_loss = 0  #Statistical total training loss
        for step, (batch_x, batch_y) in enumerate(train_loader):
            
            optimizer.zero_grad()  #Gradient zeroing
            batch_x, batch_y = batch_x.float().to(device), batch_y.float().to(device).unsqueeze(-1)
            
            # forward
            outputs = net(batch_x)
            
            # Calculate losses
            loss = criterion(outputs, batch_y)
            
            # Backpropagation, calculating gradients
            loss.backward()
            
            # Using an optimizer to update gradients
            optimizer.step()
            
            # Record the loss of the current batch
            train_loss += loss.item() * batch_x.size(0)
        
        train_mse.append(train_loss / len(train_set))
        scheduler.step()  # update scheduler
        
        # Verification Model
        valid_loss = 0
        for step, (batch_x, batch_y) in enumerate(valid_loader):
            
            batch_x, batch_y = batch_x.float().to(device), batch_y.float().to(device).unsqueeze(-1)
            
            # forward
            with torch.no_grad():
                outputs = net(batch_x)
            loss = criterion(outputs, batch_y)
            valid_loss += loss.item() * batch_x.size(0)

        valid_mse.append(valid_loss / len(valid_set))

        if epoch % 10 == 0:
            print("Epoch [{}/{}] -- train mse: {:.4f}, valid mse: {:.4f}".format(
                epoch, epochs, train_mse[-1], valid_mse[-1]))
    
    # Draw a curve chart
    plt.plot(train_mse, label='Training MSE')
    plt.plot(valid_mse, label='Validation MSE')
    plt.xlabel('Epochs')
    plt.ylabel('Mean Squared Error')
    plt.legend()
    plt.show()
    
    
    # evaluation model
    with torch.no_grad():
        X_test = torch.from_numpy(X_test).float().to(device)
        predictions = net(X_test)  # Using models for prediction
    
    X_test = X_test.cpu().numpy()
    predictions = predictions.cpu().numpy()
#
    threshold =25   # threshold

    # Create a mask that only includes points below the threshold
    mask = y_test < threshold

    # Apply masks to filter data
    filtered_y_test = y_test[mask]
    filtered_predictions = predictions[mask]

    # Redraw a scatter plot using filtered data
    plt.scatter(filtered_y_test, filtered_predictions)
    plt.xlabel('True Values')
    plt.ylabel('Predictions')
    plt.show()
#

    # Comparison between visualized real values and predicted values
    plt.scatter(y_test, predictions)
    plt.xlabel('True Values')
    plt.ylabel('Predictions')
    plt.xticks(ticks=np.arange(0, 1000, 100), rotation=90, fontsize=10)
    plt.yticks(ticks=np.arange(0, 30, 5))
    plt.show()